﻿using ActividadCRUD.Models;
using System.Data.SqlClient;
using System.Data;

namespace ActividadCRUD.Data
{
    public class DataJuegos
    {

        public List<JuegosModel> Consultar()
        {

            var oConsulta = new List<JuegosModel>();

            var cn = new Conexion();

            using (var conexion = new SqlConnection(cn.getCadenaSQL()))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("sp_Consultar", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        oConsulta.Add(new JuegosModel()
                        {
                            IdJuego = Convert.ToInt32(dr["IdJuego"]),
                            Nombre = dr["Nombre"].ToString(),
                            Genero = dr["Genero"].ToString(),
                            Plataforma = dr["Plataforma"].ToString()
                        });
                    }
                }
            }

            return oConsulta;
        }

        public JuegosModel Obtener(int IdJuego)
        {

            var oJuego = new JuegosModel();

            var cn = new Conexion();

            using (var conexion = new SqlConnection(cn.getCadenaSQL()))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("sp_ConsultaId", conexion);
                cmd.Parameters.AddWithValue("IdJuego", IdJuego);
                cmd.CommandType = CommandType.StoredProcedure;

                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        oJuego.IdJuego = Convert.ToInt32(dr["IdJuego"]);
                        oJuego.Nombre = dr["Nombre"].ToString();
                        oJuego.Genero = dr["Genero"].ToString();
                        oJuego.Plataforma = dr["Plataforma"].ToString();
                    }
                }
            }

            return oJuego;
        }

        public bool Guardar(JuegosModel ojuego)
        {
            bool asw;

            try
            {
                var cn = new Conexion();

                using (var conexion = new SqlConnection(cn.getCadenaSQL()))
                {
                    conexion.Open();
                    SqlCommand cmd = new SqlCommand("sp_Crear", conexion);
                    cmd.Parameters.AddWithValue("Nombre", ojuego.Nombre);
                    cmd.Parameters.AddWithValue("Genero", ojuego.Genero);
                    cmd.Parameters.AddWithValue("Plataforma", ojuego.Plataforma);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
                asw = true;
            }
            catch (Exception e)
            {
                string erro = e.Message;
                asw = false;
            }

            return asw;
        }

        public bool Editar(JuegosModel ojuego)
        {
            bool asw;

            try
            {
                var cn = new Conexion();

                using (var conexion = new SqlConnection(cn.getCadenaSQL()))
                {
                    conexion.Open();
                    SqlCommand cmd = new SqlCommand("sp_Editar", conexion);
                    cmd.Parameters.AddWithValue("IdJuego", ojuego.IdJuego);
                    cmd.Parameters.AddWithValue("Nombre", ojuego.Nombre);
                    cmd.Parameters.AddWithValue("Genero", ojuego.Genero);
                    cmd.Parameters.AddWithValue("Plataforma", ojuego.Plataforma);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
                asw = true;
            }
            catch (Exception e)
            {
                string erro = e.Message;
                asw = false;
            }
            return asw;
        }

        public bool Eliminar(int IdJuego)
        {
            bool asw;

            try
            {
                var cn = new Conexion();

                using (var conexion = new SqlConnection(cn.getCadenaSQL()))
                {
                    conexion.Open();
                    SqlCommand cmd = new SqlCommand("sp_Eliminar", conexion);
                    cmd.Parameters.AddWithValue("IdJuego", IdJuego);                    
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
                asw = true;
            }
            catch (Exception e)
            {
                string erro = e.Message;
                asw = false;
            }
            return asw;
        }
    }
}
