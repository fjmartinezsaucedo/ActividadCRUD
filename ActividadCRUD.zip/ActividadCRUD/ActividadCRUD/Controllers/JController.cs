﻿using Microsoft.AspNetCore.Mvc;
using ActividadCRUD.Data;
using ActividadCRUD.Models;

namespace ActividadCRUD.Controllers
{
    public class JController : Controller
    {
        DataJuegos _DataJuegos = new DataJuegos();
        public IActionResult Consultar()
        {
            var oConsulta = _DataJuegos.Consultar();
            return View(oConsulta);
        }

        public IActionResult Guardar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Guardar(JuegosModel oJuego)
        {
            if (!ModelState.IsValid)
                return View();

            var asw = _DataJuegos.Guardar(oJuego);

            if (asw)            
                return RedirectToAction("Consultar");
            else
                return View();
        }

        public IActionResult Editar(int IdJuego)
        {
            var ojuego = _DataJuegos.Obtener(IdJuego);
            return View(ojuego);
        }

        [HttpPost]
        public IActionResult Editar(JuegosModel oJuego)
        {
            if (!ModelState.IsValid)
                return View();                      

            var asw = _DataJuegos.Editar(oJuego);

            if (asw)
                return RedirectToAction("Consultar");
            else
                return View();           
        }

        public IActionResult Eliminar(int IdJuego)
        {
            var ojuego = _DataJuegos.Obtener(IdJuego);
            return View(ojuego);
        }

        [HttpPost]
        public IActionResult Eliminar(JuegosModel oJuego)
        {            
            var asw = _DataJuegos.Eliminar(oJuego.IdJuego);

            if (asw)
                return RedirectToAction("Consultar");
            else
                return View();
        }
    }
}
