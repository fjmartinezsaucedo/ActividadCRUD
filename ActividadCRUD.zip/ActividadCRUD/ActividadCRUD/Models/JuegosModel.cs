﻿using System.ComponentModel.DataAnnotations;

namespace ActividadCRUD.Models
{
    public class JuegosModel
    {
        public int IdJuego { get; set; }

        [Required(ErrorMessage = "El campo Nombre es obligatorio")]
        public string? Nombre { get; set; }

        [Required(ErrorMessage = "El campo Genero es obligatorio")]
        public string? Genero { get; set; }

        [Required(ErrorMessage = "El campo Plataforma es obligatorio")]
        public string? Plataforma { get; set; }       

    }
}
