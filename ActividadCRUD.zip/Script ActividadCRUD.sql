--Creacion de base de datos.
create database ActividadCRUD
use ActividadCRUD

--Creacion de tabla
Create table Juegos(
IdJuego int identity primary key,
Nombre varchar (50),
Genero varchar (20),
Plataforma varchar (25)
)

--Procedimiento implicito de consulta
Create procedure sp_Consultar
as begin
	select * from Juegos
end

--Procedimiento implicito especifico de consulta con ID
Create procedure sp_ConsultaId(
@IdJuego int
)
as begin
	select * from Juegos where IdJuego = @IdJuego
end

--Procedimiento para crear nuevo juego dentro de la tabla
Create procedure sp_Crear(
@Nombre varchar (50),
@Genero varchar (50),
@Plataforma varchar (50)
)
as begin
	insert into Juegos (Nombre, Genero, Plataforma) values (@Nombre, @Genero, @Plataforma)
end

--Procedimiento para editar un juego dentro de la tabla
Create procedure sp_Editar(
@IdJuego int,
@Nombre varchar (50),
@Genero varchar (50),
@Plataforma varchar (50)
)
as begin
	update Juegos set Nombre = @Nombre, Genero = @Genero, Plataforma = @Plataforma where IdJuego = @IdJuego
end

--Procedimiento para eliminar un juego dentro de la tabla
Create procedure sp_Eliminar(
@IdJuego int
)
as begin	
	delete from Juegos where IdJuego = @IdJuego
end

select * from Juegos